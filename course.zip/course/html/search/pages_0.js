var searchData=
[
  ['student_20and_20course_20struct_20and_20function_20demonstration_0',['Student and Course struct and function demonstration',['../index.html',1,'']]]
];
