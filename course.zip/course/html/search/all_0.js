var searchData=
[
  ['_5fcourse_0',['_course',['../struct__course.html',1,'']]],
  ['_5fstudent_1',['_student',['../struct__student.html',1,'']]]
];
