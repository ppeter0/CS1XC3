 /**
 * @file student.h
 * @author Peter Wardell
 * @date April 3, 2022
 * @brief Student library for managing data
 * for a student. Contains functions to edit
 * and retrieve data.
 *
 */

/**
 * @brief Defines a student with a first name,
 * last name, student ID, list of grades and number of 
 * grades.
 */
typedef struct _student 
{ 
  char first_name[50]; /**< Student's first name*/
  char last_name[50];/**< Student's last name*/
  char id[11];/**< Student ID*/
  double *grades; /**< Student's list of grades*/
  int num_grades; /**< How many grades the student recieved*/
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 