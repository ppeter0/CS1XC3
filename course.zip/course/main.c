/**
 * @mainpage Student and Course struct and function demonstration
 *  
 * The demonstration shows how multiple functions in the 
 * student and course library work, including:
 * - Creating a course
 * - Enrolling students in a course
 * - Displays the students enrolled in the course
 * - Displays the top student in the course
 * - Displays the number of students passing and who they are
 * 
 * @file main.c
 * @author Peter Wardell
 * @date April 3, 2022
 * @brief Runs demonstration code for student and course library methods.
 * 
 */ 
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief A working example of the student and course methods.
 *        Creates the course: "Basics of Mathematics, MATH 101",
 *        generates a random class list and prints information 
 *        about the course.
 * 
 * @return int Exit code
 */
int main() //Takes no command-line arguments
{
  /*Seeds the random number generator with the current time.
    This will ensure the numbers are different every 
    execution*/
  srand((unsigned) time(NULL));

  //Initialize the student array and give the course a name and code
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //Enroll 20 random students in the course
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  //Finds and prints the top student in the course
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  //Prints the number of students passing who they are
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0; //Exit code
}