/**
 * @file course.c
 * @author Peter Wardell
 * @date April 3, 2022
 * @brief Course library for managing courses.
 * Includes function definitions
 *
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief Enrolls a given student in a given course.
 * 
 * @param course The course to enroll the student in, given as a Course type
 * @param student The student to enroll, given as a Student type
 * @return Nothing
 */
void enroll_student(Course *course, Student *student)
{
  /* Allocates or reallocates memory to store the students
    enrolled in the course*/
  course->total_students++;
  if (course->total_students == 1) 
  {
    /*calloc is used because if the array has not been initialized (0 students),
      realloc cannot be used
    */
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    //When the student is already initialized (> 0 students), just reallocate memory for it
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student; //Place the student in the array
}
/**
 * @brief Prints the given course including course name, code
 * and list of students
 * 
 * @param course The Course whose information is to be printed
 * @return Nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  /*Uses print_student to print out all the information stored in the
    specific Student.*/
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}
/**
 * @brief Returns the top student in the class.
 * i.e. The student with the highest average
 * 
 * @param course The course to pick students from
 * @return Student* The student with the highest average in the course
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL; //Stop if the course is empty

  double student_average = 0;
  double max_average = average(&course->students[0]); //Set the current max to an abitrary student's grade
  Student *student = &course->students[0]; //Set to the same student that has max_average
  
  //Loops for each student in the course
  for (int i = 1; i < course->total_students; i++)
  {
    /*Takes the ith student's average and compares it to the current max
      average, replacing it if needed */
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}
/**
 * @brief Returns an array of the students passing a given course.
 *        Also updates the total_passing variable given with
 *        the number of students passing the course.
 * 
 * @param course The course to check
 * @param total_passing This will be set by the function to the number of students are passing the course
 * @return Student* The array of students who are passing the course
 */
Student *passing(Course* course, int *total_passing)
{
  //Initialize the count and list of students passing the course
  int count = 0;
  Student *passing = NULL;
  
  //Loops for each student enrolled in the course
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++; //Increment the count only if the student is passing
  
  /*Allocate space to hold the passing students. 
  Calloc is used to avoid unexpected student variables*/
  passing = calloc(count, sizeof(Student)); 

  int j = 0;
  /*Loops for each student again so we can now add
    Students to the allocated array, passing
  */
  for (int i = 0; i < course->total_students; i++)
  {
    
    if (average(&course->students[i]) >= 50) //Check if they are passing
    {
      passing[j] = course->students[i]; //Add them to passing at index j
      j++; 
    }
  }
  *total_passing = count;

  return passing;
}