/**
 * @file student.c
 * @author Peter Wardell
 * @date April 3, 2022
 * @brief Student library for managing students, including
 *        definitions of student functions.
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Adds a grade the the array of grades a Student has
 * 
 * @param student The student, as a Student type, to add the grade to
 * @param grade The grade to add
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  /*Allocate space for 1 student if the course if the course originally had none
    i.e. memory has not been allocated yet
  */
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double)); 
  else 
  {
    //If the course already has students i.e. memory has already been allocated
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade; //Add the student to the end of the array
}

/**
 * @brief Calculates the average grade of the given student
 * 
 * @param student The student whose average you want to calculate
 * @return double The given student's average
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0; //If the student has no grades, their average will be 0

  double total = 0;
  //Calculate their average using the formula for the average
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * @brief Prints formatted information about the student including,
 *        name, ID, grades, and average.
 * 
 * @param student The student whose data is to be printed
 */
void print_student(Student* student)
{
  //Print formated information for the student
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief Randomly generates a student with semi-random first 
 *        and last names, random grades and random student ID.
 *        The first and last names are picked from a
 *        predetermiend array of names.
 * 
 * @param grades The number of grades to randomly generate for the student
 * @return Student* The randomly generated student
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  //Copy the randomly chosen names to the names for the student
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  /*Generates a random number that is converted to the character is represents
    in the ASCII table, the integers 0-9. This is used to get integers as characters
    without casting*/
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';
  
  //Loops for the number of grades specified
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75))); //Adds a random grade to the random student's array
  }

  return new_student;
}