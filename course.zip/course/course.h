/**
 * @file course.h
 * @author Peter Wardell
 * @date April 3, 2022
 * @brief Course library for managing courses. 
 * Contains the Course type and functions to
 * edit / retrieve information.
 *
 */
#include "student.h"
#include <stdbool.h>

/**
 * @brief Defines a course with a course name, course code, 
 * list of students and the number of students enrolled.
 */
typedef struct _course 
{
  char name[100]; /**< Course name*/
  char code[10]; /**< Course code*/
  Student *students; /**< Array of students*/
  int total_students; /**< Number of students*/
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);